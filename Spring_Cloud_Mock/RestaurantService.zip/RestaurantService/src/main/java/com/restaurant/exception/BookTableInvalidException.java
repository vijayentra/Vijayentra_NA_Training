package com.restaurant.exception;


public class BookTableInvalidException extends Exception{



}
